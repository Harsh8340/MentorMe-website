# MentorMe
Team - Ecstasy
This is the prototye of our website MentorMe for the hackathon Mentorathon.
Here is a [video](https://drive.google.com/file/d/1qnX-pxX3Q_qS22xQau-b2xrKVQf7NNwU/view?usp=sharing) to show you the working website.

Features which have been implemented:
- Login/Signup page
- Recommendation of mentors based on matching skills
- Asking questions by mentees to mentors
- Showing similar questions before posting a question
- Sending the mentors, which have been matched according to their expertise, the question to answer.
- Forum page
- Answer form page
- All the backend connected to the above tasks

